package com.mtb.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class CommandLiner implements CommandLineRunner {
	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void run(String... args) throws Exception {
		sendEmail();
	}

	public void sendEmail() {
		String from = "fromuser@gmail.com";
		String to = "touser@gmail.com";

		SimpleMailMessage message = new SimpleMailMessage();

		message.setFrom(from);
		message.setTo(to);
		message.setSubject("This is a plain text email");
		message.setText("Hello guys! This is a plain text email.");

		mailSender.send(message);
	}

}
