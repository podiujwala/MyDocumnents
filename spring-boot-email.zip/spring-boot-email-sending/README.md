# spring-boot-email-sending
Project code for Spring Boot Email Sending Tutorial
### Read the article: [Spring Boot Email Sending Tutorial and Code Examples](https://www.codejava.net/frameworks/spring-boot/email-sending-tutorial) 
### Watch video on YouTube: [Spring Boot Email Sending Tutorial (Text, HTML, Inline and Attachment)](https://youtu.be/njPaIwdx4yw)
